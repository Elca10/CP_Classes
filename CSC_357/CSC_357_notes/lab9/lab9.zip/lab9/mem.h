#ifndef MEM_H
#define MEM_H

#include <stdlib.h>

void *lab_malloc(size_t nbytes);
void lab_free(void *);

#endif
